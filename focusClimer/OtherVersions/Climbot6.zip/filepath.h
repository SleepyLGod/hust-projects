//获取JSON文件路径
#ifndef FILEPATH_H
#define FILEPATH_H

#define SettingFilePath "./setting.json"
#define TrailFilePath "./optitrack_data.txt"
#define fishEXE "F:\\ClimbotWizardProjOL20200526\\fish_show_finlish_EXE\\fish_submitted.exe"

#endif // FILEPATH_H
