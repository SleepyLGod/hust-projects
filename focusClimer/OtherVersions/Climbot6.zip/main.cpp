#include "ClimbotWin.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    ClimbotWin w;

    w.setWindowIcon(QIcon(":/png/image/robot.png"));
    w.setWindowTitle("FocusClimer V1.0");

    w.showMaximized();

    return a.exec();
}
