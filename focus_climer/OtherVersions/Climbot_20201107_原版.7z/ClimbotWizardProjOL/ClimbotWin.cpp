





#include "ClimbotWin.h"
#include "ui_ClimbotWin.h"
#include <filepath.h>
#include "QDebug"
#include <QTime>
#include <QProcess>
#include "dataview.h"
#include <QHostAddress>
#include <QFile>

ClimbotWin::ClimbotWin(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::ClimbotWin)
{
    ui->setupUi(this);
    ui->InfoTable->setColumnWidth(2,500);
    UpdateInfo("Normal","start");
    ConRbt=new ConnectRobot(SettingFilePath);
    UpdateInfo("Normal","Loading settings");
    BeauCli();
    Panelinit();
    DataviewInit();
    QDateTime current_time =QDateTime::currentDateTime();
    QString filename = current_time.toString("yyyy-MM-dd-HH-mm-ss") + ".txt";
    file = new QFile(filename);
}

ClimbotWin::~ClimbotWin()
{
    delete panel1;
    delete panel2;
    delete panel3;
    delete graph3D;
    delete ui;
}


void ClimbotWin::UpdateInfo(QString Type, QString data)
{
    QDateTime current_time =QDateTime::currentDateTime();

    ui->InfoTable->insertRow(0);
    ui->InfoTable->setItem(0,0,new QTableWidgetItem(current_time.toString("yyyy-MM-dd HH:mm:ss")));
    ui->InfoTable->setItem(0,1,new QTableWidgetItem(Type));
    ui->InfoTable->setItem(0,2,new QTableWidgetItem(data));
}

void ClimbotWin::BeauCli()
{
    ui->ConnectBtn->setToolTip("连接设备");
    ui->LoadSettingBtn->setToolTip("连接设置");
    ui->EMCBtn->setToolTip("急停按钮");
    ui->StartBtn->setToolTip("开始工作");
    ui->FinishBtn->setToolTip("停止工作");

    ui->lineEdit_1->setReadOnly(1);
    ui->lineEdit_2->setReadOnly(1);
    ui->lineEdit_3->setReadOnly(1);
    ui->lineEdit_4->setReadOnly(1);
    ui->lineEdit_5->setReadOnly(1);
    ui->lineEdit_6->setReadOnly(1);
    ui->PathlineEdit->setReadOnly(1);

    ui->distanceComb->setCurrentIndex(0);

    ui->InfoTable->horizontalHeader()->setDefaultAlignment(Qt::AlignHCenter);
    ui->InfoTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->InfoTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->InfoTable->horizontalHeader()->setStyleSheet("QHeaderView::section{background:rgb(2,20,130);color: white;}");
    ui->InfoTable->setSelectionBehavior(QAbstractItemView::SelectRows);

    ButtonDisable();
}

void ClimbotWin::Panelinit()
{

    panel1=new panel(ui->panel1);
    panel2=new panel(ui->panel2);
    panel3=new panel(ui->panel3);

    panel1->setTitle("风腔1");
    panel2->setTitle("风腔2");
    panel3->setTitle("风腔3");
}

void ClimbotWin::DataviewInit()
{
    //光滑曲线序列
    seriesLine = new QSplineSeries();
    seriesLine1 = new QSplineSeries();
    seriesLine2 = new QSplineSeries();
    //平面图散点数据分配空间
    series0 = new QScatterSeries();
    series1 = new QScatterSeries();
    series2 = new QScatterSeries();

    //三维图点的数据分配空间
    graph3D = new Q3DScatter();
    graphContainer = QWidget::createWindowContainer(graph3D); //Q3DBars继承自QWindow，必须如此创建
    QScatterDataProxy *proxy = new QScatterDataProxy(); //数据代理
    series_3D = new QScatter3DSeries(proxy);  //创建序列，问题的关键

    QHBoxLayout *hlayout=new QHBoxLayout();
    hlayout->addWidget(graphContainer,2);
    ui->fm_3D->setLayout(hlayout);

    //信号与槽，创建定时器
    timer_t = new QTimer(this);
    connect(timer_t,SIGNAL(timeout()),this,SLOT(BuildGraph3D()));

    connect(timer_t,SIGNAL(timeout()),this,SLOT(RemoveSeries));
    connect(timer_t,SIGNAL(timeout()),this,SLOT(buildScatterChart()));

}

void ClimbotWin::ButtonEnable()
{
    ui->UpBtn->setEnabled(1);
    ui->DownBtn->setEnabled(1);
    ui->LeftBtn->setEnabled(1);
    ui->RightBtn->setEnabled(1);
    ui->StopBtn->setEnabled(1);
    ui->cwBtn->setEnabled(1);
    ui->ccwBtn->setEnabled(1);

    ui->distanceComb->setEnabled(1);

}

void ClimbotWin::ButtonDisable()
{
    ui->UpBtn->setEnabled(0);
    ui->DownBtn->setEnabled(0);
    ui->LeftBtn->setEnabled(0);
    ui->RightBtn->setEnabled(0);
    ui->StopBtn->setEnabled(0);
    ui->cwBtn->setEnabled(0);
    ui->ccwBtn->setEnabled(0);

    ui->distanceComb->setEnabled(0);


}
//操作按钮
void ClimbotWin::on_ConnectBtn_clicked()
{
    if(!file->open(QIODevice::WriteOnly | QIODevice::Text))
    {
        qDebug() << "Open failed." << endl;
        return;
    }


    tcpSocket = nullptr;
    tcpSocket = new QTcpSocket(this);

    //tcp建立连接成功，显示成功建立信息
    connect(tcpSocket, &QTcpSocket::connected,
            [=]()
            {
                UpdateInfo("Normal", "Connect to Tcp Server");
            });

    connect(tcpSocket, &QTcpSocket::readyRead,this,&ClimbotWin::UpdateFanData);

    //从setting.json文件读取服务器IP和端口号
    QString ip;
    quint16 port = 0;
    ConRbt->GetServerIP_Port(ip, port);

    //建立tcp连接
    tcpSocket->connectToHost(QHostAddress(ip), port);

    //显示连接信息
    UpdateInfo("Normal","Connect Server,IP:Port:"+ip+":"+QString::number(port));
    UpdateInfo("Normal","Connect OptiTrick,IP:Port:"+ConRbt->GetOptiTrackIP_Port());
    UpdateInfo("Normal","3D&2D display is turned on");
    file->write("Connect successfully!\n");
    ButtonEnable();
    timer_t->start(500);

    fan_1 = ui->lineEdit_Fan->text().toInt();
    fan_2 = ui->lineEdit_Fan_2->text().toInt();
    fan_3 = ui->lineEdit_Fan_3->text().toInt();
    QString start_str = QString("manual\t0.0\t0.0\t0.0\t%1\t%2\t%3\r\n").arg(fan_1).arg(fan_2).arg(fan_3);
    tcpSocket->write(start_str.toLatin1());
    UpdateInfo("Normal","The polish mission is started");
    file->write("The polish mission is started\n");
}

void ClimbotWin::on_StartBtn_clicked()
{
    fan_1 = ui->lineEdit_Fan->text().toInt();
    fan_2 = ui->lineEdit_Fan_2->text().toInt();
    fan_3 = ui->lineEdit_Fan_3->text().toInt();
    QString path_following_str = QString("path_follow\t0.0\t0.0\t0.0\t%1\t%2\t%3\r\n").arg(fan_1).arg(fan_2).arg(fan_3);
    tcpSocket->write(path_following_str.toLatin1());
    UpdateInfo("Nomal", "The polish mission is path following");
    file->write("The polish mission is path following\n");
}

void ClimbotWin::on_StopBtn_clicked()
{
    fan_1 = ui->lineEdit_Fan->text().toInt();
    fan_2 = ui->lineEdit_Fan_2->text().toInt();
    fan_3 = ui->lineEdit_Fan_3->text().toInt();
    QString pause_str = QString("manual\t0.0\t0.0\t0.0\t%1\t%2\t%3\r\n").arg(fan_1).arg(fan_2).arg(fan_3);
    tcpSocket->write(pause_str.toLatin1());
    UpdateInfo("Normal","The polish mission is paused");
    file->write("The polish mission is paused\n");
}

void ClimbotWin::on_FinishBtn_clicked()
{
    //断开与服务器连接
    tcpSocket->write("stop\r\n", 7);
    tcpSocket->disconnectFromHost();
    UpdateInfo("Normal","The polish mission is stopped");
    file->write("Normal The polish mission is stopped\n");
    file->close();
    timer_t->stop();
}

void ClimbotWin::on_EMCBtn_clicked()
{
    //断开与服务器连接
    tcpSocket->write("emergency\r\n", 12);
    tcpSocket->disconnectFromHost();
    file->write("Emergency Stop is pressed!\n");
    file->close();
    timer_t->stop();
    UpdateInfo("Normal","Emergency Stop is pressed!");
}

void ClimbotWin::on_LoadSettingBtn_clicked()
{
    if(ConRbt->RefreshSettingData())
        UpdateInfo("Normal","setting file is refreshed");
}

void ClimbotWin::on_OpenFileBtn_clicked()
{
    QString fileName = QFileDialog::getOpenFileName(this, tr("open file"), " ",  tr("Allfile(*.*)"));
    ui->PathlineEdit->setText(fileName);
    if(ui->PathlineEdit->text()!="")
    {
        UpdateInfo("Normal","File loaded successful");
    }
    else
    {
        UpdateInfo("Normal","Failed to load file");
    }

}

void ClimbotWin::on_UpBtn_clicked()
{
    fan_1 = ui->lineEdit_Fan->text().toInt();
    fan_2 = ui->lineEdit_Fan_2->text().toInt();
    fan_3 = ui->lineEdit_Fan_3->text().toInt();
    distance = ui->distanceComb->currentText().toDouble();
    QString up_str =
            QString("manual\t0.0\t%1\t0.0\t%2\t%3\t%4\r\n").arg(distance*1e-3).arg(fan_1).arg(fan_2).arg(fan_3);
    tcpSocket->write(up_str.toLatin1());
    file->write(up_str.toLatin1());
    UpdateInfo("Normal", "Up");
}

void ClimbotWin::on_LeftBtn_clicked()
{
    fan_1 = ui->lineEdit_Fan->text().toInt();
    fan_2 = ui->lineEdit_Fan_2->text().toInt();
    fan_3 = ui->lineEdit_Fan_3->text().toInt();
    distance = ui->distanceComb->currentText().toDouble();
    QString left_str =
            QString("manual\t%1\t0.0\t0.0\t%2\t%3\t%4\r\n").arg(-distance*1e-3).arg(fan_1).arg(fan_2).arg(fan_3);
    tcpSocket->write(left_str.toLatin1());
    file->write(left_str.toLatin1());
    UpdateInfo("Normal", "Left");
}

void ClimbotWin::on_RightBtn_clicked()
{
    fan_1 = ui->lineEdit_Fan->text().toInt();
    fan_2 = ui->lineEdit_Fan_2->text().toInt();
    fan_3 = ui->lineEdit_Fan_3->text().toInt();
    distance = ui->distanceComb->currentText().toDouble();
    QString right_str =
            QString("manual\t%1\t0.0\t0.0\t%2\t%3\t%4\r\n").arg(distance*1e-3).arg(fan_1).arg(fan_2).arg(fan_3);
    tcpSocket->write(right_str.toLatin1());
    file->write(right_str.toLatin1());
    UpdateInfo("Normal", "Right");
}

void ClimbotWin::on_DownBtn_clicked()
{
    fan_1 = ui->lineEdit_Fan->text().toInt();
    fan_2 = ui->lineEdit_Fan_2->text().toInt();
    fan_3 = ui->lineEdit_Fan_3->text().toInt();
    distance = ui->distanceComb->currentText().toDouble();
    QString down_str =
            QString("manual\t0.0\t%1\t0.0\t%2\t%3\t%4\r\n").arg(-distance*1e-3).arg(fan_1).arg(fan_2).arg(fan_3);
    tcpSocket->write(down_str.toLatin1());
    file->write(down_str.toLatin1());
    UpdateInfo("Normal", "Down");
}

void ClimbotWin::on_cwBtn_clicked()
{
    fan_1 = ui->lineEdit_Fan->text().toInt();
    fan_2 = ui->lineEdit_Fan_2->text().toInt();
    fan_3 = ui->lineEdit_Fan_3->text().toInt();
    ang_vel = ui->lineEdit_AngVel->text().toDouble();
    QString clockwise_str =
            QString("manual\t0.0\t0.0\t%1\t%2\t%3\t%4\r\n").arg(ang_vel).arg(fan_1).arg(fan_2).arg(fan_3);
    tcpSocket->write(clockwise_str.toLatin1());
    file->write(clockwise_str.toLatin1());
    UpdateInfo("Normal", "clockwise");
}

void ClimbotWin::on_ccwBtn_clicked()
{
    fan_1 = ui->lineEdit_Fan->text().toInt();
    fan_2 = ui->lineEdit_Fan_2->text().toInt();
    fan_3 = ui->lineEdit_Fan_3->text().toInt();
    ang_vel = ui->lineEdit_AngVel->text().toDouble();
    QString counterclockwise_str =
            QString("manual\t0.0\t0.0\t%1\t%2\t%3\t%4\r\n").arg(-ang_vel).arg(fan_1).arg(fan_2).arg(fan_3);
    tcpSocket->write(counterclockwise_str.toLatin1());
    file->write(counterclockwise_str.toLatin1());
    UpdateInfo("Normal", "counterclockwise");
}

//风腔气压值更新槽函数
void ClimbotWin::UpdateFanData()
{
    QString fan_data = QString(tcpSocket->readLine());
    if(fan_data.right(2) == "\r\n")
    {
        fan_data = fan_data.left(fan_data.length()-2);
        QStringList fan_data_list = fan_data.split(",");

        if(fan_data_list.size() != 3)
        {
            return;
        }

        panel1->setValue(-fan_data_list[0].toDouble());
        panel2->setValue(-fan_data_list[1].toDouble());
        panel3->setValue(-fan_data_list[2].toDouble());

        QString fan_data = "Fan pressure:["+fan_data_list[0]+"\t"+fan_data_list[1]+"\t"+fan_data_list[2]+"]\n";
        file->write(fan_data.toLatin1());
    }
    return;
}
