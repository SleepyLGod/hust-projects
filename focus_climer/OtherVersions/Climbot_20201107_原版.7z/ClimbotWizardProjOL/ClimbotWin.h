
#ifndef CLIMBOTWIN_H
#define CLIMBOTWIN_H

#include <QMainWindow>
#include <connectrobot.h>
//#include "fish_show_finsih/fish.h"
#include "panel.h"
//#include "dataview.h"
#include <QWidget>
#include <QtCharts>  //必须这么设置
#include <QtDataVisualization>
#include <QTimer>
#include <QTcpSocket>
#include <QFile>
#include <QTextStream>

using QtDataVisualization::Q3DScatter;
using QtDataVisualization::QScatter3DSeries;
using QtDataVisualization::QScatterDataProxy;
using QtDataVisualization::QAbstract3DSeries;
using QtDataVisualization::QAbstract3DGraph;
using QtDataVisualization::Q3DCamera;
using QtDataVisualization::QScatterDataArray;
using QtDataVisualization::Q3DTheme;


namespace Ui
{
class ClimbotWin;
}

class ClimbotWin : public QMainWindow
{
    Q_OBJECT

public:
    explicit ClimbotWin(QWidget *parent = nullptr);
    ~ClimbotWin();
    void UpdateInfo(QString Type,QString data);
    void BeauCli();
    void Panelinit();
    void DataviewInit();

    void ButtonEnable();
    void ButtonDisable();

private:
    QWidget     *graphContainer;//
    Q3DScatter  *graph3D;       //散点图
    QScatter3DSeries *series_3D;  //散点序列
  //初始化绘图
   void  iniScatterChart();
   void  iniGraph3D();

private slots:
    void on_ConnectBtn_clicked();

    void on_StartBtn_clicked();

    void on_FinishBtn_clicked();

    void on_EMCBtn_clicked();

    void on_LoadSettingBtn_clicked();

    void on_OpenFileBtn_clicked();
    /*
    //panel
    void UpdateData1();
    void UpdateData2();
    void UpdateData3();
    */
    //dataview

    void buildScatterChart();

    void BuildGraph3D();

    void on_UpBtn_clicked();

    void on_RightBtn_clicked();

    void on_LeftBtn_clicked();

    void on_DownBtn_clicked();

    void on_cwBtn_clicked();

    void on_ccwBtn_clicked();

    void UpdateFanData();

    void on_StopBtn_clicked();

private:
    Ui::ClimbotWin *ui;
    ConnectRobot* ConRbt;
    //panel
    panel *panel1;
    panel *panel2;
    panel *panel3;

    QTimer *updateTimer1;
    QTimer *updateTimer2;
    QTimer *updateTimer3;
    //dataview
    QTimer* timer_t;

    qreal A;
    qreal B;
    qreal C;
    qreal D;
    qreal G;

    qreal H;
    qreal I;
    qreal J;
    qreal R;
    qreal T;

    qreal m_M;
    qreal m_S;
    qreal m_E;

    float M;
    float S;
    float E;
    double F;
    double r;
    double t;

    QScatterSeries *series0;
    QScatterSeries *series1;
    QScatterSeries *series2;

    QSplineSeries *seriesLine;
    QSplineSeries *seriesLine1;
    QSplineSeries *seriesLine2;

    QValueAxis *axisX ;
    QValueAxis *axisX1 ;
    QValueAxis *axisX2 ;

    QValueAxis *axisY;
    QValueAxis *axisY1;
    QValueAxis *axisY2;

private:
    QTcpSocket *tcpSocket;      //tcp通信套接字
    int fan_1, fan_2, fan_3; //风腔负压值
    double ang_vel;             //旋转角速度
    double distance;
    QFile *file;


};

#endif // MAINWINDOW_H
