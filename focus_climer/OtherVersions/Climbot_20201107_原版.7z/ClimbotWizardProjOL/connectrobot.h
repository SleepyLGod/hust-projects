#ifndef CONNECTROBOT_H
#define CONNECTROBOT_H

#include "QFile"
#include "QString"
#include "QJsonDocument"
#include "QJsonParseError"
#include <QJsonValue>
#include <QJsonArray>
#include <QJsonObject>
#include "QDebug"

class ConnectRobot
{
public:
    ConnectRobot(QString SettingFile);
    void GetServerIP_Port(QString &ip, quint16 &port);
    QString GetOptiTrackIP_Port();

    int RefreshSettingData();
private:
    QByteArray SettingData;
    QString SettingFilePath;


};

#endif // CONNECTROBOT_H
